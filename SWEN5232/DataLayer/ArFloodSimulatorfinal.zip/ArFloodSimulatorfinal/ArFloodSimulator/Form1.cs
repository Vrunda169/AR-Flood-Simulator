﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SWEN5232.DataLayer;
using SWEN5232.Models;
using System.Device.Location;

namespace ArFloodSimulator
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
            webBrowser1.Visible = false;
        }

        private async void BtnGetCurrentLoc_Click(object sender, EventArgs e)
        {
            LocationDL locationDl = new LocationDL();
            Location currentLocationInFirebase = await locationDl.GetCurrentLocation();
            MessageBox.Show($"Latitude is: {currentLocationInFirebase.Latitude} and Longitude is: {currentLocationInFirebase.Longitude}");
        }

        private void BtnSetCurrentLoc_Click(object sender, EventArgs e)
        {
            SetCurrentLocationForm setForm = new SetCurrentLocationForm();
            setForm.ShowDialog();
        }

        private void BtnOpenProject_Click(object sender, EventArgs e)
        {
            OpenProjectForm openProjectForm = new OpenProjectForm();
            openProjectForm.ShowDialog();
        }

        private async void BtnLocationTracking_Click(object sender, EventArgs e)
        {
            GeoCoordinateWatcher locationWatcher = new GeoCoordinateWatcher();
            locationWatcher.TryStart(true, TimeSpan.FromMilliseconds(2000));
            await Task.Delay(2000);
            var coords = locationWatcher.Position.Location;
            if (coords.IsUnknown != true)
            {
                _ = Task.Run(() => MessageBox.Show($"Latitud: {coords.Latitude}\nLongitude: {coords.Longitude}", "Location Updated"));
                StringBuilder queryAddress = new StringBuilder();
                queryAddress.Append("http://maps.google.com/maps?q=");
                queryAddress.Append(coords.Latitude + "%2C");
                queryAddress.Append(coords.Longitude);
                webBrowser1.Visible = true;
                webBrowser1.Navigate(queryAddress.ToString());
            }
            else
            {
                MessageBox.Show("Cannot find location.", "Unknown Locationo");
            }
        }
    }
}
