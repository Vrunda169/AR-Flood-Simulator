﻿namespace ArFloodSimulator
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnOpenProject = new System.Windows.Forms.Button();
            this.BtnLocationTracking = new System.Windows.Forms.Button();
            this.webBrowser1 = new System.Windows.Forms.WebBrowser();
            this.SuspendLayout();
            // 
            // BtnOpenProject
            // 
            this.BtnOpenProject.Location = new System.Drawing.Point(213, 80);
            this.BtnOpenProject.Name = "BtnOpenProject";
            this.BtnOpenProject.Size = new System.Drawing.Size(185, 23);
            this.BtnOpenProject.TabIndex = 2;
            this.BtnOpenProject.Text = "Project Details";
            this.BtnOpenProject.UseVisualStyleBackColor = true;
            this.BtnOpenProject.Click += new System.EventHandler(this.BtnOpenProject_Click);
            // 
            // BtnLocationTracking
            // 
            this.BtnLocationTracking.Location = new System.Drawing.Point(213, 35);
            this.BtnLocationTracking.Name = "BtnLocationTracking";
            this.BtnLocationTracking.Size = new System.Drawing.Size(185, 23);
            this.BtnLocationTracking.TabIndex = 3;
            this.BtnLocationTracking.Text = "Get Current Location";
            this.BtnLocationTracking.UseVisualStyleBackColor = true;
            this.BtnLocationTracking.Click += new System.EventHandler(this.BtnLocationTracking_Click);
            // 
            // webBrowser1
            // 
            this.webBrowser1.Location = new System.Drawing.Point(17, 201);
            this.webBrowser1.MinimumSize = new System.Drawing.Size(20, 20);
            this.webBrowser1.Name = "webBrowser1";
            this.webBrowser1.Size = new System.Drawing.Size(573, 254);
            this.webBrowser1.TabIndex = 4;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(625, 487);
            this.Controls.Add(this.webBrowser1);
            this.Controls.Add(this.BtnLocationTracking);
            this.Controls.Add(this.BtnOpenProject);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AR Flood Simulator";
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button BtnOpenProject;
        private System.Windows.Forms.Button BtnLocationTracking;
        private System.Windows.Forms.WebBrowser webBrowser1;
    }
}

