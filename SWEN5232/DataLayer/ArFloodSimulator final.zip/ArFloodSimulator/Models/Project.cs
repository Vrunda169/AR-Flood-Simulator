﻿using System;
using System.Collections.Generic;

namespace SWEN5232.Models
{
    [Serializable]
    public class Project
    {
        public Project()
        {
            AllModels = new List<Model>();
        }

        public Location Location { get; set; }
        public string ProjectName { get; set; }
        public int FloodLevel { get; set; }

        public List<Model> AllModels;
    }
}
