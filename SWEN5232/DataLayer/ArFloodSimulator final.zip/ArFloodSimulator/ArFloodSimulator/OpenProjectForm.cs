﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Device.Location;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SWEN5232.DataLayer;
using SWEN5232.Models;

namespace ArFloodSimulator
{
    public partial class OpenProjectForm : Form
    {
        private Dictionary<string, Project> projectList; // List of all the projects with id.
        private Project AllModelsProject = new Project();

        /// <summary>
        /// Constructor of the class. Called by system.
        /// </summary>
        public OpenProjectForm()
        {
            InitializeComponent();
            
        }

        /// <summary>
        /// Called when the form is opened. 
        /// This is called only one time when form is loaded.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void OpenProjectForm_Load(object sender, EventArgs e)
        {
            projectListCombo.Enabled = false;
            panelProjectData.Visible = false;
            BtnUpdate.Visible = false;
            BtnEditCncl.Enabled = false;
            BtnCancelSaveProject.Visible = false;
            BtnNewSaveProj.Enabled = false;
            BtnDeleteProj.Visible = false;
            await FillComboBox();
            BtnNewSaveProj.Enabled = true;
            BtnDeleteProj.Visible = true;
            DisableEditing();
            projectListCombo.Enabled = true;
            BtnCancelSaveProject.Visible = false; // cancel button of save project.
            BtnGetLocation.Enabled = false;
            BtnAddMoreBuildings.Text = "Show Models";
        }

        /// <summary>
        /// Called on load of form and fills the dropdown list.
        /// </summary>
        /// <returns></returns>
        public async Task FillComboBox()
        {
            BtnEditCncl.Enabled = false;
            ProjectDL projectDL = new ProjectDL();
            projectList = await projectDL.GetAllProjects();

            List<Tuple<string, string>> projectIdNameList = new List<Tuple<string, string>>();
            foreach (var item in projectList)
            {
                projectIdNameList.Add(new Tuple<string, string>(item.Key, item.Value.ProjectName));
            }

            projectListCombo.ValueMember = "Item1";
            projectListCombo.DisplayMember = "Item2";
            projectListCombo.DataSource = projectIdNameList;
            BtnEditCncl.Enabled = true;
        }

        /// <summary>
        /// When user changes the project in list and selects other project.
        /// </summary>
        private void FillAndShowProjDtls()
        {
            var projectID = projectListCombo.SelectedValue as string;
            var projectDetails = projectList.First(P => P.Key == projectID).Value;

            textBoxProjectName.Text = projectDetails.ProjectName;
            textBoxFloodLevel.Text = projectDetails.FloodLevel + "";
            textBoxProjLati.Text = projectDetails.Location.Latitude;
            textBoxProjLongi.Text = projectDetails.Location.Longitude;
            textBoxProjAddress.Text = projectDetails.Location.Address;

            panelProjectData.Visible = true;
        }

        /// <summary>
        /// Called when user selects differenct project from list.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ProjectListCombo_SelectedIndexChanged(object sender, EventArgs e)
        {
            FillAndShowProjDtls();
        }

        /// <summary>
        /// Called when editing is cancelled.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnEditCncl_Click(object sender, EventArgs e)
        {
            if (BtnEditCncl.Text == "Edit")
            {
                BtnEditCncl.Text = "Cancel";
                BtnUpdate.Visible = true;
                BtnNewSaveProj.Visible = false;
                projectListCombo.Enabled = false;
                BtnAddMoreBuildings.Text = "Add Models";
                EnableEditing();
                
            }
            else if (BtnEditCncl.Text == "Cancel")
            {
                BtnEditCncl.Text = "Edit";
                BtnUpdate.Visible = false;
                projectListCombo.Enabled = true;
                DisableEditing();
                FillAndShowProjDtls();
                BtnNewSaveProj.Visible = true;
                BtnAddMoreBuildings.Text = "Show Models";
            }
        }

        /// <summary>
        /// Utility function to disable editing of all project fields.
        /// called from multiple actions.
        /// </summary>
        private void DisableEditing()
        {
            textBoxProjectName.Enabled = false;
            textBoxFloodLevel.Enabled = false;
            textBoxProjLati.Enabled = false;
            textBoxProjLongi.Enabled = false;
            textBoxProjAddress.Enabled = false;
            BtnGetLocation.Enabled = false;
        }

        /// <summary>
        /// Utility function to enable editing of all project fields.
        /// called from multiple actions.
        /// </summary>
        private void EnableEditing()
        {
            textBoxProjectName.Enabled = true;
            textBoxFloodLevel.Enabled = true;
            textBoxProjLati.Enabled = true;
            textBoxProjLongi.Enabled = true;
            textBoxProjAddress.Enabled = true;

            BtnGetLocation.Enabled = true;
        }

        /// <summary>
        /// Called on click of update button project.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void BtnUpdate_Click(object sender, EventArgs e)
        {
            var projectId = projectListCombo.SelectedValue as string;

            var ProjectFromLst = projectList.First(P => P.Key == projectId);
            var projectData = ReadAllFields();
            projectData.AllModels = new List<Model>(ProjectFromLst.Value.AllModels);
            bool isUpdated = false;

            if (IsValidProjectData(projectData))
            {
                ProjectDL projectDL = new ProjectDL();
                isUpdated = await projectDL.UpdateProject(projectId, projectData);
            }

            if (isUpdated)
            {

                Task task = FillComboBox();
                MessageBox.Show("Project Updated Successfully");
                await task;
                projectListCombo.Enabled = true;
                BtnEditCncl.Text = "Edit";
                BtnUpdate.Visible = false;
                BtnNewSaveProj.Visible = true;
                DisableEditing();
                projectListCombo.SelectedValue = projectId;
            }
        }

        /// <summary>
        /// Reads all the project fields from the form and returns a Project object
        /// </summary>
        /// <returns></returns>
        private Project ReadAllFields()
        {
            Project project = new Project
            {
                ProjectName = textBoxProjectName.Text,
                FloodLevel = string.IsNullOrEmpty(textBoxFloodLevel.Text) ? int.MinValue : int.Parse(textBoxFloodLevel.Text),
                Location = new Location
                {
                    Latitude = string.IsNullOrEmpty(textBoxProjLati.Text) ? "" : float.Parse(textBoxProjLati.Text) + "",
                    Longitude = string.IsNullOrEmpty(textBoxProjLongi.Text) ? "" : float.Parse(textBoxProjLongi.Text) + "",
                    Address = textBoxProjAddress.Text
                }
            };

            return project;
        }

        /// <summary>
        /// Validation of all the fields are done in this function
        /// </summary>
        /// <param name="projectDetails"></param>
        /// <returns></returns>
        private bool IsValidProjectData(Project projectDetails)
        {
            var isValid = true;

            StringBuilder validationMsg = new StringBuilder();
            if (string.IsNullOrEmpty(projectDetails.ProjectName))
            {
                validationMsg.Append("Project name cannot be empty.");
                isValid = false;
            }

            if (projectDetails.FloodLevel == int.MinValue)
            {
                validationMsg.Append(Environment.NewLine + "Flood level cannot be empty.");
                isValid = false;
            }

            if (string.IsNullOrEmpty(projectDetails.Location.Latitude))
            {
                validationMsg.Append(Environment.NewLine + "Latitude cannot be empty.");
                isValid = false;
            }

            if (string.IsNullOrEmpty(projectDetails.Location.Longitude))
            {
                validationMsg.Append(Environment.NewLine + "Longitude cannot be empty.");
                isValid = false;
            }

            if (string.IsNullOrEmpty(projectDetails.Location.Address))
            {
                validationMsg.Append(Environment.NewLine + "Address cannot be empty.");
                isValid = false;
            }

            if (!isValid)
            {
                MessageBox.Show(validationMsg.ToString());
            }

            return isValid;
        }

        /// <summary>
        /// Checks if Number is only allowed in text field.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void AllowNumberOnly(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        /// <summary>
        /// Checks if decimal is only allowed in text field.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void AllowDecimalOnly(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            // only allow one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

        /// <summary>
        /// Called when Save Project or New Prject is clicked because both button has same action.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void BtnNewSaveProj_Click(object sender, EventArgs e)
        {
            if (BtnNewSaveProj.Text == "New Project")
            {
                HandleNewProjAction();
                BtnNewSaveProj.Text = "Save";
            }
            else if (BtnNewSaveProj.Text == "Save")
            {
                await HandleSaveProjAction();

            }


        }

        /// <summary>
        /// Called when Save project button is called.
        /// </summary>
        /// <returns></returns>
        private async Task HandleSaveProjAction()
        {
            var newProjectDtls = ReadAllFields();
            bool isvalid = IsValidProjectData(newProjectDtls);

            newProjectDtls.AllModels = AllModelsProject.AllModels;
            if (isvalid)
            {
                ProjectDL projectDL = new ProjectDL();

                bool isSaved = await projectDL.CreateNewProject(newProjectDtls);
                if (isSaved)
                {
                    AfterSaveProject();
                }
            }
        }

        /// <summary>
        /// Called after project is saved in firebase database.
        /// </summary>
        public void AfterSaveProject()
        {
            FillComboBox();
            MessageBox.Show("Project Created Successfully.");
            BtnCancelSaveProject.Visible = false;
            projectListCombo.Visible = true;
            projectListCombo.Enabled = false;
            BtnEditCncl.Visible = true;
            BtnUpdate.Visible = false;
            BtnNewSaveProj.Visible = true;
            BtnNewSaveProj.Text = "New Project";
            BtnDeleteProj.Visible = true;
            BtnGetLocation.Enabled = false;
            projectListCombo.Enabled = true;
            DisableEditing();
            AllModelsProject = null;
            BtnAddMoreBuildings.Text = "Show Models";
        }

        /// <summary>
        /// Called when new project button is clicked.
        /// </summary>
        private void HandleNewProjAction()
        {
            BtnCancelSaveProject.Visible = true;
            projectListCombo.Visible = false;
            BtnDeleteProj.Visible = false;
            BtnGetLocation.Enabled = true;
            BtnAddMoreBuildings.Text = "Add Models";
            BlankAllFields();
            EnableEditing();
        }

        /// <summary>
        /// Clears all the fields.
        /// </summary>
        private void BlankAllFields()
        {
            textBoxProjectName.Text = null;
            textBoxFloodLevel.Text = null;
            textBoxProjLati.Text = null;
            textBoxProjLongi.Text = null;
            textBoxProjAddress.Text = null;
        }

        /// <summary>
        /// Called when cancel button is clicked.
        /// If you want to cancel creating a project.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnCancelSaveProject_Click(object sender, EventArgs e)
        {
            BtnNewSaveProj.Text = "New Project";
            BtnEditCncl.Visible = true;
            projectListCombo.Visible = true;
            BtnEditCncl.Text = "Edit";
            BtnCancelSaveProject.Visible = false;
            BtnGetLocation.Enabled = false;
            DisableEditing();
            FillAndShowProjDtls();
            BtnDeleteProj.Visible = true;
            BtnAddMoreBuildings.Text = "Show Models";
        }

        /// <summary>
        /// Called when delete project button is clicked.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void BtnDeleteProj_Click(object sender, EventArgs e)
        {
            ProjectDL projDl = new ProjectDL();
            var projID = projectListCombo.SelectedValue as string;
            bool isDeleted = await projDl.DeleteProject(projID);
            if (isDeleted)
            {
                FillComboBox();
                MessageBox.Show("Project Deleted Successfully.", "Success");
            }
        }

        /// <summary>
        /// Called on click of Get Location button on new project form.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void BtnGetLocation_Click(object sender, EventArgs e)
        {
            await GetDeviceLocation();
        }

        /// <summary>
        /// Gets the device location and display it on map. 
        /// It also fills the new project latitude and longitude.
        /// </summary>
        /// <returns></returns>
        private async Task GetDeviceLocation()
        {
            GeoCoordinateWatcher locationWatcher = new GeoCoordinateWatcher();
            locationWatcher.TryStart(true, TimeSpan.FromMilliseconds(2000));
            await Task.Delay(2000);
            var coords = locationWatcher.Position.Location;
            if (coords.IsUnknown != true)
            {
                //_ = Task.Run(() => MessageBox.Show($"Latitud: {coords.Latitude}\nLongitude: {coords.Longitude}", "Location Updated")); // will run async

                Location location = new Location
                {
                    Latitude = coords.Latitude.ToString(),
                    Longitude = coords.Longitude.ToString(),
                    Altitude = coords.Altitude.ToString()
                };

                LocationDL locationDl = new LocationDL();
                _ = locationDl.SetCurrentLocation(location); // will run async

                string mapLocationStr = $"https://www.google.com/maps/search/?api=1&map_action=map&zoom=11&query={coords.Latitude}%2C{coords.Longitude}";

                mapBrowser.Visible = true;
                mapBrowser.Navigate(mapLocationStr);

                LocationDL locDl = new LocationDL();
                await locDl.SetCurrentLocation(
                new Location
                {
                    Latitude = coords.Latitude.ToString(),
                    Longitude = coords.Longitude.ToString()
                });

                textBoxProjLati.Text = coords.Latitude.ToString();
                textBoxProjLongi.Text = coords.Longitude.ToString();
            }
            else
            {
                MessageBox.Show("Cannot find location.", "Unknown Locationo");
            }
        }

        /// <summary>
        /// Called when Add Models button is clicked in main project form.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnAddModels_Click(object sender, EventArgs e)
        {

            var mode = (sender as Button).Text == "Show Models" ? "RO" : "EDIT";

            //AdditionalModelsForm additionalModelsForm = new AdditionalModelsForm(currentProject);
            AdditionalModelsForm additionalModelsForm = null;

            if (BtnNewSaveProj.Text == "Save")
            {
                // It indicates we are creating a new project and not updating.
                if (AllModelsProject == null)
                {
                    AllModelsProject = new Project();
                }
                additionalModelsForm = new AdditionalModelsForm(AllModelsProject, mode);
            }
            else
            {
                var currentProjectID = projectListCombo.SelectedValue as string;
                var currentProject = projectList.First(P => P.Key == currentProjectID).Value;
                additionalModelsForm = new AdditionalModelsForm(currentProject, mode);
            }

            DialogResult dialogResult = additionalModelsForm.ShowDialog();
            if (dialogResult == DialogResult.OK)
            {
                //Called when user will close the form
            }
        }

    }
}
