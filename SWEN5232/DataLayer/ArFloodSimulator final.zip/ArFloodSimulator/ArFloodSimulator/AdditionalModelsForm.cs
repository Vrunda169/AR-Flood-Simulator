﻿using SWEN5232.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ArFloodSimulator
{
    public partial class AdditionalModelsForm : Form
    {
        public Project currentProject { get; set; }
        public List<Model> TempModels { get; set; }

        public string mode = "";

        /// <summary>
        /// calls when this form is loaded.
        /// </summary>
        /// <param name="currentProject"></param>
        public AdditionalModelsForm(Project currentProject, string mode)
        {
            InitializeComponent();
            this.currentProject = currentProject;
            Text = currentProject.ProjectName + " - Models" ;

            TempModels = new List<Model>();
            if (currentProject.AllModels != null && currentProject.AllModels.Any())
            {
                TempModels = new List<Model>(currentProject.AllModels);
            }
            panel1.AutoScroll = true;
            this.mode = mode;
            if (this.mode == "RO")
            {
                BtnAddModel.Enabled = false;
                BtnSaveModels.Enabled = false;
            }

            ClearPanelAndAddModels();
            
        }


        /// <summary>
        /// Called when Add Model Button is Clicked.
        /// This button generated new fields dynamically.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnAddModel_Click(object sender, EventArgs e)
        {
            SaveModelsInternally(false);
            TempModels.Add(new Model() { Name = "__NEW__PROJECT__" });
            ClearPanelAndAddModels();
        }

        /// <summary>
        /// This method Creates textboxes and delete button for every model in project.
        /// called from different places to refresh the list and recreates the fields.
        /// </summary>
        private void ClearPanelAndAddModels()
        {
            panel1.Controls.Clear();
            for (int i = 0; i < TempModels.Count; i++)
            {
                bool isNewProject = IsNewProject(TempModels[i]);

                var textboxModelName = new TextBox();
                textboxModelName.Name = $"textboxModelName_{i}";
                textboxModelName.Text = isNewProject ? "" : TempModels[i].Name;
                textboxModelName.Top = i * 28;
                textboxModelName.Width = 150;
                textboxModelName.Left = 2;
                textboxModelName.Enabled = mode == "EDIT";
                panel1.Controls.Add(textboxModelName);

                var textboxModelType = new TextBox();
                textboxModelType.Name = $"textboxModelType_{i}";
                textboxModelType.Text = isNewProject ? "" : TempModels[i].Type;
                textboxModelType.Top = i * 28;
                textboxModelType.Width = 150;
                textboxModelType.Left = 160;
                textboxModelType.Enabled = mode == "EDIT";
                panel1.Controls.Add(textboxModelType);

                var textboxModelShape = new TextBox();
                textboxModelShape.Name = $"textboxModelShape_{i}";
                textboxModelShape.Text = isNewProject ? "" : TempModels[i].Shape;
                textboxModelShape.Top = i * 28;
                textboxModelShape.Width = 150;
                textboxModelShape.Left = 320;
                textboxModelShape.Enabled = mode == "EDIT";
                panel1.Controls.Add(textboxModelShape);

                var textboxModelHeight = new TextBox();
                textboxModelHeight.Name = $"textboxModelHeight_{i}";
                textboxModelHeight.Text = isNewProject ? "0" : TempModels[i].Height.ToString();
                textboxModelHeight.Top = i * 28;
                textboxModelHeight.Width = 150;
                textboxModelHeight.Left = 480;
                textboxModelHeight.Enabled = mode == "EDIT";
                panel1.Controls.Add(textboxModelHeight);

                var textboxModelWidth = new TextBox();
                textboxModelWidth.Name = $"textboxModelWidth_{i}";
                textboxModelWidth.Text = isNewProject ? "0" : TempModels[i].Width.ToString();
                textboxModelWidth.Top = i * 28;
                textboxModelWidth.Width = 150;
                textboxModelWidth.Left = 640;
                textboxModelWidth.Enabled = mode == "EDIT";
                panel1.Controls.Add(textboxModelWidth);

                var textboxModelLength = new TextBox();
                textboxModelLength.Name = $"textboxModelLength_{i}";
                textboxModelLength.Text = isNewProject ? "0" : TempModels[i].Length.ToString();
                textboxModelLength.Top = i * 28;
                textboxModelLength.Width = 150;
                textboxModelLength.Left = 800;
                textboxModelLength.Enabled = mode == "EDIT";
                panel1.Controls.Add(textboxModelLength);

                var deleteBtn = new Button();
                deleteBtn.Text = "X";
                deleteBtn.Name = $"{i}";
                deleteBtn.Top = i * 28;
                deleteBtn.Width = 30;
                deleteBtn.Left = 800 + 160;
                deleteBtn.Height = deleteBtn.Height - 2;
                deleteBtn.Enabled = mode == "EDIT";
                deleteBtn.Click += DeleteBtn_Click;
                panel1.Controls.Add(deleteBtn);

            }
        }

        /// <summary>
        /// Deleted the added Building
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DeleteBtn_Click(object sender, EventArgs e)
        {
            var button = sender as Button;
            TempModels.RemoveAt(int.Parse(button.Name));
            ClearPanelAndAddModels();
        }

        /// <summary>
        /// This method checks if the added project is new or was already exist.
        /// </summary>
        /// <param name="building"></param>
        /// <returns></returns>
        private bool IsNewProject(Model building)
        {
            return building.Name == "__NEW__PROJECT__";
        }

        /// <summary>
        /// Saves the Model into Project
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnSaveModels_Click(object sender, EventArgs e)
        {
            SaveModelsInternally(true);
        }

        /// <summary>
        /// Saves the List internally and makes model permanent.
        /// </summary>
        /// <param name="isPermanent"></param>
        private void SaveModelsInternally(bool isPermanent)
        {
            var isValid = true;

            for (int i = 0; i < TempModels.Count; i++)
            {
                var textBoxNameOfBuilding = panel1.Controls.Find($"textboxModelName_{i}", false).First() as TextBox;
                var textBoxTypeOfBuilding = panel1.Controls.Find($"textboxModelType_{i}", false).First() as TextBox;
                var textBoxBuildingShape = panel1.Controls.Find($"textboxModelShape_{i}", false).First() as TextBox;
                var textBoxBuildingHeight = panel1.Controls.Find($"textboxModelHeight_{i}", false).First() as TextBox;
                var textBoxBuildingWidth = panel1.Controls.Find($"textboxModelWidth_{i}", false).First() as TextBox;
                var textBoxBuildingLength = panel1.Controls.Find($"textboxModelLength_{i}", false).First() as TextBox;

                var isValidHeight = int.TryParse(textBoxBuildingHeight.Text, out int height);
                var isValidWidth = int.TryParse(textBoxBuildingWidth.Text, out int width);
                var isValidLength = int.TryParse(textBoxBuildingLength.Text, out int length);

                if (isPermanent)
                {
                    if (string.IsNullOrEmpty(textBoxNameOfBuilding.Text))
                    {
                        MessageBox.Show($"Please Enter Name.");
                        textBoxNameOfBuilding.Focus();
                        isValid = false;
                        break;
                    }

                    if (string.IsNullOrEmpty(textBoxTypeOfBuilding.Text))
                    {
                        MessageBox.Show($"Please Enter Type.");
                        textBoxTypeOfBuilding.Focus();
                        isValid = false;
                        break;
                    }

                    if (string.IsNullOrEmpty(textBoxBuildingShape.Text))
                    {
                        MessageBox.Show($"Please Enter Shape.");
                        textBoxBuildingShape.Focus();
                        isValid = false;
                        break;
                    }

                    if (string.IsNullOrEmpty(textBoxBuildingHeight.Text) || textBoxBuildingHeight.Text == "0")
                    {
                        MessageBox.Show($"Please Enter Height.");
                        textBoxBuildingHeight.Focus();
                        isValid = false;
                        break;
                    }
                    else if (!isValidHeight)
                    {
                        MessageBox.Show($"Please Enter Valid Height in Numbers.");
                        textBoxBuildingHeight.Focus();
                        isValid = false;
                        break;
                    }

                    if (string.IsNullOrEmpty(textBoxBuildingWidth.Text) || textBoxBuildingWidth.Text == "0")
                    {
                        MessageBox.Show($"Please Enter Width.");
                        textBoxBuildingWidth.Focus();
                        isValid = false;
                        break;
                    }
                    else if (!isValidWidth)
                    {
                        MessageBox.Show($"Please Enter Valid Width in Numbers.");
                        textBoxBuildingWidth.Focus();
                        isValid = false;
                        break;
                    }

                    if (string.IsNullOrEmpty(textBoxBuildingLength.Text) || textBoxBuildingLength.Text == "Length" || textBoxBuildingLength.Text == "0")
                    {
                        MessageBox.Show($"Please Enter Length.");
                        textBoxBuildingLength.Focus();
                        isValid = false;
                        break;
                    }
                    else if (!isValidLength)
                    {
                        MessageBox.Show($"Please Enter Valid Length in Numbers.");
                        textBoxBuildingWidth.Focus();
                        isValid = false;
                        break;
                    } 
                }

                TempModels[i] = new Model
                {
                    Name = string.IsNullOrEmpty(textBoxNameOfBuilding.Text) ? string.Empty : textBoxNameOfBuilding.Text,
                    Type = string.IsNullOrEmpty(textBoxTypeOfBuilding.Text) ? string.Empty : textBoxTypeOfBuilding.Text,
                    Shape = string.IsNullOrEmpty(textBoxBuildingShape.Text) ? string.Empty : textBoxBuildingShape.Text,
                    Height = height,
                    Width = width,
                    Length = length
                };
            }

            if (isValid && isPermanent)
            {
                currentProject.AllModels = new List<Model>(TempModels);
                MessageBox.Show("Models Saved Successfully.\nPlease Save/Update Project to Persist Data.");
            }
        }

        /// <summary>
        /// Sets dialog result on close of form.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void AdditionalModelsForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (TempModels.Count != currentProject.AllModels.Count)
            {
                var confirmResult = MessageBox.Show("Are you sure you want to Exit, ther are unsaved changes","EXIT !", MessageBoxButtons.YesNo);
                if (confirmResult == DialogResult.Yes)
                {
                    e.Cancel = false;
                }
                else
                {
                    e.Cancel = true;
                }
            }


            DialogResult = DialogResult.OK;
        }
    }
}
